/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package login_phim;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javafx.scene.input.MouseEvent;


import java.io.*;
import java.util.Arrays;import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import login_phim.man_hinh_chinh.FXML_ManHinhChinhController;


/**
 *
 * @author LENOVO
 */

public class FXMLDocumentController implements Initializable {
    public static String usernameSignUpGet="";
    String usernameSignInGet="",passwordSignInGet="",
            passwordSignUpGet="",confirmPasswordSignUpGet="",recoveryCodeSignUpGet="",
            //rset
            usernameResetGet="",passwordResetGet="",confirmPasswordResetGet="",recoveryCodeResetGet="";
            
    
    @FXML private Label createAnAccount, forgotPassword, falsePassword, falseCode,thongBaoSignUp,thongBaoReset;
    @FXML private TextField accountSignIn, passwordSignIn, accountSignUp, passwordSignUp, confirmPasswordSignUp, recoveryCodeSignUp, accountReset, passwordReset, confirmPasswordReset,codeReset;
    @FXML private Button createAnAccout;
    @FXML private Pane paneDangKi, paneQuenMatKhau, paneDangNhap;
   
    
    //Pane Đăng Nhập
    //@FXML private void signInOn(ActionEvent event) {  }
    @FXML private void createAnAccountOn(MouseEvent event) {
        
        paneDangKi.setDisable(false);
        paneDangKi.setOpacity(1);
        paneDangNhap.setDisable(true);
        paneDangNhap.setOpacity(0);
        paneQuenMatKhau.setDisable(true);
        paneQuenMatKhau.setOpacity(0);
    }
    @FXML private void forgotPasswordOn(MouseEvent event)  {
        paneDangKi.setDisable(true);
        paneDangKi.setOpacity(0);
        paneDangNhap.setDisable(true);
        paneDangNhap.setOpacity(0);
        paneQuenMatKhau.setDisable(false);
        paneQuenMatKhau.setOpacity(1);
    }
    
   // ✅ Đường dẫn tương đối: nằm cạnh thư mục src/
    private static final String FILE_PATH = "accout/account.csv";

    // 🔍 Hàm kiểm tra username tồn tại
    private static boolean findUsername(String keyword) throws IOException {
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            System.out.println(" KhOng tIm thAy file CSV tại: " + file.getAbsolutePath());
            return false;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 0 && values[0].trim().equals(keyword)) {
                    return true;
                }
            }
        }

        return false;
    }

    // Lấy giá trị password tại username
    private static String getPassword(String keyword) throws IOException {
    File file = new File("accout/account.csv");  // đường dẫn tương đối
    if (!file.exists()) {
        System.out.println("⚠️ Không tìm thấy file CSV!");
        return "";
    }

    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            if (values.length > 1 && values[0].trim().equals(keyword)) {
                return values[1].trim(); // cột password
            }
        }
    }

    return "";
}

    // Lấy giá trị recoverycode từ username
    private static String getRecoveryCode(String keyword) throws IOException {
        File file = new File("accout/account.csv");  // đường dẫn tương đối
        if (!file.exists()) {
            System.out.println("⚠️ Không tìm thấy file CSV!");
            return "";
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > 2 && values[0].trim().equals(keyword)) {
                    return values[2].trim(); // cột thứ 3 là recovery code
                }
            }
        }

        return "";
    }
    // Cập nhật mật khẩu mới cho username
    private static void updatePassword(String username, String passwordNew) throws IOException {
        File file = new File("accout/account.csv");
        if (!file.exists()) {
            System.out.println("⚠️ Không tìm thấy file CSV!");
            return;
        }

        // Đọc toàn bộ file vào bộ nhớ
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                // Nếu username trùng thì thay mật khẩu
                if (values.length > 1 && values[0].trim().equals(username)) {
                    values[1] = passwordNew.trim(); // cập nhật cột password
                    line = String.join(",", values);
                }
                lines.add(line);
            }
        }

        // Ghi lại toàn bộ file với mật khẩu mới
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, false))) {
            for (String l : lines) {
                bw.write(l);
                bw.newLine();
            }
        }

        System.out.println("✅ Đã cập nhật mật khẩu cho user: " + username);
    }

    // thêm tài khoản vào cuối
    private static void createAccountNew(String username_create, String password_create, String recoveryCode_create) throws IOException {
        // ✅ Đường dẫn tương đối tính từ thư mục project (nằm cạnh src)
        File file = new File("accout/account.csv");

        // Nếu file hoặc thư mục chưa có -> tự tạo
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }

        // ✅ Ghi nối tiếp vào cuối file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
            bw.write(username_create + "," + password_create + "," + recoveryCode_create);

            bw.newLine();// xuống dòng
            System.out.println(" Đã thêm tài khoản: " + username_create);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // pane Đăng kí
    @FXML private void createAccountSignUpOn (ActionEvent event)throws IOException {
           
            usernameSignUpGet = accountSignUp.getText();
            //xem trong file exel co tai khoan do chua
            if ((findUsername(usernameSignUpGet)||usernameSignUpGet.isEmpty())){
                thongBaoSignUp.setText("This username already exists.");
                thongBaoSignUp.setStyle("-fx-border-color#ff0000;");
            }
            else{
                thongBaoSignUp.setText("username ok.");
                thongBaoSignUp.setStyle("-fx-border-color#22ff00;"); 
                passwordSignUpGet = passwordSignUp.getText();
                confirmPasswordSignUpGet = confirmPasswordSignUp.getText();
                recoveryCodeSignUpGet = recoveryCodeSignUp.getText();
                if(
                        (!passwordSignUpGet.isEmpty()&&!confirmPasswordSignUpGet.isEmpty())
                            &&passwordSignUpGet.equals( confirmPasswordSignUpGet)
                                && (!recoveryCodeSignUpGet.isEmpty())
                        ){
                    createAccountNew(usernameSignUpGet,passwordSignUpGet,recoveryCodeSignUpGet);
                    System.out.print("tk da duoc tao");
                    paneDangKi.setDisable(true);
                    paneDangKi.setOpacity(0);
                    paneDangNhap.setDisable(false);
                    paneDangNhap.setOpacity(1);
                    paneQuenMatKhau.setDisable(true);
                    paneQuenMatKhau.setOpacity(0);
                    
                    
                }
                else {
                    System.out.print("password sai");
                    thongBaoSignUp.setText("username ok; mật khẩu không trùng khớp");
                }
            }
    }
    @FXML private void backSignUpOn(ActionEvent event){
        paneDangKi.setDisable(true);
        paneDangKi.setOpacity(0);
        paneDangNhap.setDisable(false);
        paneDangNhap.setOpacity(1);
        paneQuenMatKhau.setDisable(true);
        paneQuenMatKhau.setOpacity(0);
    }
    //Pane dổi mật khẩu, quên mật khẩu
    @FXML private void resetPasswordResetOn(ActionEvent event) throws IOException {
        usernameResetGet = accountReset.getText();
        passwordResetGet = passwordReset.getText();
        if (findUsername(usernameResetGet)){
            System.out.print(getRecoveryCode(usernameResetGet));
            if (codeReset.getText().equals(getRecoveryCode(usernameResetGet))){
                if((!passwordResetGet.isEmpty()&&!confirmPasswordReset.getText().isEmpty())
                                &&passwordResetGet.equals(confirmPasswordReset.getText())){
                    updatePassword(usernameResetGet,passwordResetGet);
                    paneDangKi.setDisable(true);
                    paneDangKi.setOpacity(0);
                    paneDangNhap.setDisable(false);
                    paneDangNhap.setOpacity(1);
                    paneQuenMatKhau.setDisable(true);
                    paneQuenMatKhau.setOpacity(0);
                }else{
                thongBaoReset.setText("mật khẩu không khớp");
                }
            }else{
            thongBaoReset.setText("Recovery Code Không chính xác");
            }
        }else{
        thongBaoReset.setText("Tài Khoảng không tồn tại");
        }
    }
    @FXML private void backResetOn(ActionEvent event){
        paneDangKi.setDisable(true);
        paneDangKi.setOpacity(0);
        paneDangNhap.setDisable(false);
        paneDangNhap.setOpacity(1);
        paneQuenMatKhau.setDisable(true);
        paneQuenMatKhau.setOpacity(0);}



@FXML
private void signInOn(ActionEvent event) throws IOException {

    // Lấy username & password người dùng nhập
    usernameSignInGet = accountSignIn.getText();
    passwordSignInGet = passwordSignIn.getText();

    // Kiểm tra có tồn tại username không
    if (findUsername(usernameSignInGet)) {
        // Kiểm tra password có khớp không
        if (passwordSignInGet.equals(getPassword(usernameSignInGet))) {
            System.out.println("password đúng");

            // 1. Tạo loader và load màn hình chính
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/login_phim/man_hinh_chinh/FXML_ManHinhChinh.fxml")
            );
            Parent root = loader.load(); // PHẢI load trước khi getController

            // 2. Lấy controller của màn hình chính
            FXML_ManHinhChinhController controller = loader.getController();

            // 3. Truyền username sang màn hình chính
            controller.setUsername(usernameSignInGet);

            // 4. Mở stage mới
            Stage newStage = new Stage();
            newStage.setScene(new Scene(root));
            newStage.setTitle("MIKEE Cinema");
            newStage.show();

            // 5. Đóng stage đăng nhập hiện tại
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

        } else {
            // Sai mật khẩu
            falsePassword.setText("Sai mật khẩu?");
        }

    } else {
        // Không tìm thấy tài khoản
        falsePassword.setText("Tài khoản không tồn tại");
    }
}


    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
