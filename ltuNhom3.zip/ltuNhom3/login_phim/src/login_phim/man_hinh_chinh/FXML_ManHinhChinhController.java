/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package login_phim.man_hinh_chinh;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import login_phim.FXMLDocumentController;

/**
 * FXML Controller class
 *
 * @author LENOVO
 */
public class FXML_ManHinhChinhController implements Initializable {
//lấy username từ file FXMLFDocumentController.java
private String usernameLogin;
private String username;

    

public void setUsername(String username) {
    this.usernameLogin = username;                     // gán vào biến thật dùng
    System.out.println("Nhận username: " + usernameLogin);

    if (xinChao != null) {                             // nếu label đã sẵn sàng
        xinChao.setText("Xin Chào: " + usernameLogin); // cập nhật luôn UI
    }
}
   @FXML
    private Label welcomeLabel;

    @FXML private Pane paneManHinhChinh, paneChonSuat, paneMuaDo2310, paneMuaDo2410, paneMuaDo2510,paneGhe,paneLichSu;
    @FXML private Button dangXuat,lichSu,
            button1,button2,button3,button4,button5,button6,button7,button8,
            button9,button10,button11,button12,button13,button14,button15,
            button16,button17,button18,button19,button20,button21,button22,
            button23,button24,button25,button26,button27,button28,button29,
            button30,button31,button32,button33,button34,button35,button36,
            button37,button38,button39,button40,button41,button42,button43,
            button44,button45,button46,button47,button48;
    @FXML private ImageView images_nen;
    @FXML private Label labelMuaDo2310, labelMuaDo2410, labelMuaDo2510,xinChao,
            //địa điểm
            labelDiaDiem1_1,labelDiaDiem1_2,
            labelDiaDiem2_1,labelDiaDiem2_2,
            labelDiaDiem3_1,labelDiaDiem3_2,
            //thời gian
                //layout 1
            labelTime1_1_1,labelTime1_1_2,labelTime1_1_3,
            labelTime1_2_1,labelTime1_2_2,labelTime1_2_3,
                //layout 2
            labelTime2_1_1,labelTime2_1_2,labelTime2_1_3,
            labelTime2_2_1,labelTime2_2_2,labelTime2_2_3,
                //layout 3
            labelTime3_1_1,labelTime3_1_2,labelTime3_1_3,
            labelTime3_2_1,labelTime3_2_2,labelTime3_2_3;
    String tempLichSuPhim ="",tempLichSuNgayChieu="",tempLichSuDiaDiem="",tempLichSuGioChieu="",tempLichSuSoGhe="";
    Boolean coGioChieu=false,coSoGhe=false,coNgayChieu=false,coPhim=false,
            coMuaDo=false,coLatMat7=false,coMai=false,coDenAmHon=false,coBoGia=false,
            coLabelTime1_1_1=false,
            coLabelTime1_1_2=false,
            coLabelTime1_1_3=false,
            coLabelTime1_2_1=false,
            coLabelTime1_2_2=false,
            coLabelTime1_2_3=false,
            coLabelTime2_1_1=false,
            coLabelTime2_1_2=false,
            coLabelTime2_1_3=false,
            coLabelTime2_2_1=false,
            coLabelTime2_2_2=false,
            coLabelTime2_2_3=false,
            coLabelTime3_1_1=false,
            coLabelTime3_1_2=false,
            coLabelTime3_1_3=false,
            coLabelTime3_2_1=false,
            coLabelTime3_2_2=false,
            coLabelTime3_2_3=false;
    //chọn label giờ chiếu
    //layout 1_1  
    private void resetColorLabelNgay(){
        labelMuaDo2310.setStyle("-fx-background-color: ffffff;-fx-background-radius:13;");
        labelMuaDo2410.setStyle("-fx-background-color: ffffff;-fx-background-radius:13;");
        labelMuaDo2510.setStyle("-fx-background-color: ffffff;-fx-background-radius:13;");
    }
    private void paneSoGheOn(){
        paneManHinhChinh.setDisable(true);
        paneManHinhChinh.setOpacity(0.5);
        paneChonSuat.setDisable(true);
        paneChonSuat.setOpacity(0);
        images_nen.setOpacity(1);
        dangXuat.setDisable(true);
        dangXuat.setOpacity(0.5);
        lichSu.setDisable(true);
        lichSu.setOpacity(0.5);
        paneGhe.setDisable(false);
        paneGhe.setOpacity(1);
    }



    @FXML private void labelTime1_1_1Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime1_1_1=true;
        chayChuongTrinh();
        
    } 
    @FXML private void labelTime1_1_2Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime1_1_2=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime1_1_3Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime1_1_3=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime1_2_1Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime1_2_1=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime1_2_2Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime1_2_2=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime1_2_3Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime1_2_3=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime2_1_1Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime2_1_1=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime2_1_2Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime2_1_2=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime2_1_3Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime2_1_3=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime2_2_1Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime2_2_1=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime2_2_2Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime2_2_2=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime2_2_3Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime2_2_3=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime3_1_1Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime3_1_1=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime3_1_2Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime3_1_2=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime3_1_3Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime3_1_3=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime3_2_1Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime3_2_1=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime3_2_2Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime3_2_2=true;
        chayChuongTrinh();
    } 
    @FXML private void labelTime3_2_3Mouse(MouseEvent even){
        paneSoGheOn();
        coLabelTime3_2_3=true;
        chayChuongTrinh();
    }
    //button chon ghe
    @FXML private void quayVeManHinhChinh(){
        paneManHinhChinh.setDisable(false);
        paneManHinhChinh.setOpacity(1);
        paneChonSuat.setDisable(true);
        paneChonSuat.setOpacity(0);
        images_nen.setOpacity(1);
        dangXuat.setDisable(false);
        dangXuat.setOpacity(1);
        lichSu.setDisable(false);
        lichSu.setOpacity(1);
        paneGhe.setDisable(true);
        paneGhe.setOpacity(0);
                    try {
                addLichSuVe(
                    "Name: "+usernameLogin,
                    tempLichSuPhim,
                    tempLichSuNgayChieu,
                    "Địa Điểm: "+tempLichSuDiaDiem,
                    tempLichSuGioChieu,
                    tempLichSuSoGhe
                );
            } catch (IOException e) {
                e.printStackTrace();
            } 
        System.out.println("\n\nPhim: "+tempLichSuPhim+"\nNgay chieu: "+tempLichSuNgayChieu+"\nDia diem: "+tempLichSuDiaDiem+"\nGio Chieu: "+tempLichSuGioChieu+"\nSoGhe: "+tempLichSuSoGhe);
        tempLichSuPhim="";tempLichSuNgayChieu="";tempLichSuGioChieu="";tempLichSuSoGhe="";tempLichSuDiaDiem="";
        coGioChieu=false;coSoGhe=false;coNgayChieu=false;
            coLabelTime1_1_1=false;
            coLabelTime1_1_2=false;
            coLabelTime1_1_3=false;
            coLabelTime1_2_1=false;
            coLabelTime1_2_2=false;
            coLabelTime1_2_3=false;
            coLabelTime2_1_1=false;
            coLabelTime2_1_2=false;
            coLabelTime2_1_3=false;
            coLabelTime2_2_1=false;
            coLabelTime2_2_2=false;
            coLabelTime2_2_3=false;
            coLabelTime3_1_1=false;
            coLabelTime3_1_2=false;
            coLabelTime3_1_3=false;
            coLabelTime3_2_1=false;
            coLabelTime3_2_2=false;
            coLabelTime3_2_3=false;
            coMuaDo=false;coLatMat7=false;coMai=false;coDenAmHon=false;coBoGia=false;

    }    
    @FXML private void button1On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A1";
        quayVeManHinhChinh();
    }
    @FXML private void button2On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A2";
        quayVeManHinhChinh();
    }
    @FXML private void button3On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A3";
        quayVeManHinhChinh();
    }
    @FXML private void button4On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A4";
        quayVeManHinhChinh();
    }
    @FXML private void button5On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A5";
        quayVeManHinhChinh();
    }
    @FXML private void button6On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A6";
        quayVeManHinhChinh();
    }
    @FXML private void button7On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A7";
        quayVeManHinhChinh();
    }
    @FXML private void button8On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: A8";
        quayVeManHinhChinh();
    }

    @FXML private void button9On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B1";
        quayVeManHinhChinh();
    }
    @FXML private void button10On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B2";
        quayVeManHinhChinh();
    }
    @FXML private void button11On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B3";
        quayVeManHinhChinh();
    }
    @FXML private void button12On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B4";
        quayVeManHinhChinh();
    }
    @FXML private void button13On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B5";
    }
    @FXML private void button14On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B6";
        quayVeManHinhChinh();
    }
    @FXML private void button15On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B7";
        quayVeManHinhChinh();
    }
    @FXML private void button16On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: B8";
        quayVeManHinhChinh();
    }
    @FXML private void button17On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C1";
        quayVeManHinhChinh();
    }
    @FXML private void button18On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C2";
        quayVeManHinhChinh();
    }
    @FXML private void button19On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C3";
        quayVeManHinhChinh();
    }
    @FXML private void button20On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C4";
        quayVeManHinhChinh();
    }
    @FXML private void button21On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C5";
        quayVeManHinhChinh();
    }
    @FXML private void button22On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C6";
        quayVeManHinhChinh();
    }
    @FXML private void button23On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C7";
        quayVeManHinhChinh();
    }
    @FXML private void button24On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: C8";
        quayVeManHinhChinh();
    }
    @FXML private void button25On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D1";
        quayVeManHinhChinh();
    }
    @FXML private void button26On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D2";
        quayVeManHinhChinh();
    }
    @FXML private void button27On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D3";
        quayVeManHinhChinh();
    }
    @FXML private void button28On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D4";
        quayVeManHinhChinh();
    }
    @FXML private void button29On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D5";
        quayVeManHinhChinh();
    }
    @FXML private void button30On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D6";
        quayVeManHinhChinh();
    }
    @FXML private void button31On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D7";
        quayVeManHinhChinh();
    }
    @FXML private void button32On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: D8";
        quayVeManHinhChinh();
    }

    @FXML private void button33On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E1";
        quayVeManHinhChinh();
    }
    @FXML private void button34On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E2";
        quayVeManHinhChinh();
    }
    @FXML private void button35On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E3";
        quayVeManHinhChinh();
    }
    @FXML private void button36On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E4";
        quayVeManHinhChinh();
    }
    @FXML private void button37On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E5";
        quayVeManHinhChinh();
    }
    @FXML private void button38On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E6";
        quayVeManHinhChinh();
    }
    @FXML private void button39On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E7";
        quayVeManHinhChinh();
    }
    @FXML private void button40On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: E8";
        quayVeManHinhChinh();
    }
    @FXML private void button41On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F1";
        quayVeManHinhChinh();
    }
    @FXML private void button42On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F2";
        quayVeManHinhChinh();
    }
    @FXML private void button43On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F3";
        quayVeManHinhChinh();
    }
    @FXML private void button44On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F4";
        quayVeManHinhChinh();
    }
    @FXML private void button45On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F5";
        quayVeManHinhChinh();
    }
    @FXML private void button46On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F6";
        quayVeManHinhChinh();
    }
    @FXML private void button47On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F7";
        quayVeManHinhChinh();
    }
    @FXML private void button48On(ActionEvent even){
        paneSoGheOn();
        tempLichSuSoGhe="Ghế: F8";
        quayVeManHinhChinh();
    }   

    @FXML private void clickMovie(){
        paneManHinhChinh.setDisable(true);
        paneManHinhChinh.setOpacity(0.5);
        paneChonSuat.setDisable(false);
        paneChonSuat.setOpacity(1);
        images_nen.setOpacity(0.2);
        dangXuat.setDisable(true);
        dangXuat.setOpacity(0.1);
        lichSu.setDisable(true);
        lichSu.setOpacity(0.1);
        paneMuaDo2310.setDisable(true);
        paneMuaDo2410.setDisable(true);
        paneMuaDo2510.setDisable(true);
    }
    @FXML private void backkOn(MouseEvent event){
        paneManHinhChinh.setDisable(false);
        paneManHinhChinh.setOpacity(1);
        paneChonSuat.setDisable(true);
        paneChonSuat.setOpacity(0);
        images_nen.setOpacity(1);
        dangXuat.setDisable(false);
        dangXuat.setOpacity(1);
        lichSu.setDisable(false);
        lichSu.setOpacity(1);
        paneLichSu.setDisable(true);
        paneLichSu.setOpacity(0);
        tempLichSuPhim="";tempLichSuNgayChieu="";tempLichSuGioChieu="";tempLichSuSoGhe="";
    }
    
    @FXML private void resetText(){
    //nạp dữ liệu địa điểm và thời gian
            //ngay
            labelMuaDo2310.setText(null);
            
            labelMuaDo2410.setText(null);
            labelMuaDo2510.setText(null);
            //địa điểm
                 //layout 1
                labelDiaDiem1_1.setText(null);
                labelDiaDiem1_2.setText(null);
                
                //layout 2
                labelDiaDiem2_1.setText(null);
                labelDiaDiem2_2.setText(null);
                
                //layout 3
                labelDiaDiem3_1.setText(null);
                labelDiaDiem3_2.setText(null);
                
           //thoi gian
             //layout 1
            labelTime1_1_1.setText(null);
            labelTime1_1_2.setText(null);
            labelTime1_1_3.setText(null);
            labelTime1_2_1.setText(null);
            labelTime1_2_2.setText(null);
            labelTime1_2_3.setText(null);
            //layout 2
                labelTime2_1_1.setText(null);
                labelTime2_1_3.setText(null);
                labelTime2_1_2.setText(null);
                labelTime2_2_1.setText(null);
                labelTime2_2_2.setText(null);
                labelTime2_2_3.setText(null);
                //layout3
            labelTime3_1_1.setText(null);
            labelTime3_1_2.setText(null);
            labelTime3_1_3.setText(null);
            labelTime3_2_1.setText(null);
            labelTime3_2_2.setText(null);
            labelTime3_2_3.setText(null);
    }
    //muaDo click
    @FXML private void latMat7On(MouseEvent enven){
        coLatMat7=true;
        clickMovie();
        resetText();
        resetColorLabelNgay();
        //nạp dữ liệu địa điểm và thời gian
            //ngay
            
            tempLichSuPhim ="Phim: Lặt Mặt 7";
            labelMuaDo2310.setText("  23/10");
            labelMuaDo2410.setText("  24/10");
            labelMuaDo2510.setText("  25/10");
            //địa điểm
                 //layout 1
                labelDiaDiem1_1.setText("Galaxy Sala");
                labelDiaDiem1_2.setText("Galaxy Nguyễn Du");
                
                //layout 2
                labelDiaDiem2_1.setText("Galaxy Nguyễn Du");
                labelDiaDiem2_2.setText("Galaxy Tân Bình");
                
                //layout 3
                labelDiaDiem3_1.setText("Galaxy Quang Trung");
                labelDiaDiem3_2.setText("Galaxy Sala");
           //thoi gian
             //layout 1
            
            labelTime1_1_1.setText("  09:45 (Còn 0/50)");
            labelTime1_1_2.setText("  11:00 (Còn 0/50)");
            labelTime1_1_3.setText("  13:00 (Còn 0/50)");
            labelTime1_2_1.setText("  15:00 (Còn 0/50)");
            labelTime1_2_2.setText("  17:00 (Còn 0/50)");
            labelTime1_2_3.setText("  19:45 (Còn 0/50)");
            //layout 2
                labelTime2_1_1.setText("  09:45 (Còn 0/50)");
                labelTime2_1_3.setText("  14:00 (Còn 0/50)");
                labelTime2_1_2.setText("  13:15 (Còn 0/50)");
                labelTime2_2_1.setText("  14:15 (Còn 0/50)");
                labelTime2_2_2.setText("  16:15 (Còn 0/50)");
                labelTime2_2_3.setText("  18:15 (Còn 0/50)");
                //layout3
            labelTime3_1_1.setText("  19:00 (Còn 0/50)");
            labelTime3_1_2.setText("  20:30 (Còn 0/50)");
            labelTime3_1_3.setText("  21:30 (Còn 0/50)");
            labelTime3_2_1.setText("  14:15 (Còn 0/50)");
            labelTime3_2_2.setText("  15:15 (Còn 0/50)");
            labelTime3_2_3.setText("  16:15 (Còn 0/50)");
            
    }
    @FXML private void muaDoOn(MouseEvent enven){
        coMuaDo=true;
        resetColorLabelNgay();
        tempLichSuPhim ="Phim: Mưa Đỏ";
        
        clickMovie();
        resetText();
        //nạp dữ liệu địa điểm và thời gian
            //ngay
            
            labelMuaDo2310.setText("  23/10");
            labelMuaDo2410.setText("  24/10");
            labelMuaDo2510.setText("  25/10");
            //địa điểm
                 //layout 1
                labelDiaDiem1_1.setText("CGV Aeon Bình Tân");
                labelDiaDiem1_2.setText("CGV Tân Phú");
                
                //layout 2
                labelDiaDiem2_1.setText("CGV Hoàng Văn Thụ");
                labelDiaDiem2_2.setText("Lotte Gò Vấp");
                
                //layout 3
                labelDiaDiem3_1.setText("Lotte Nam Sài Gòn");
                labelDiaDiem3_2.setText("Lotte Phú Thọ");
           //thoi gian
             //layout 1
            labelTime1_1_1.setText("  08:45 (Còn 0/50)");
            labelTime1_1_2.setText("  10:00 (Còn 0/50)");
            labelTime1_1_3.setText("  11:00 (Còn 0/50)");
            labelTime1_2_1.setText("  12:00 (Còn 0/50)");
            labelTime1_2_2.setText("  14:00 (Còn 0/50)");
            labelTime1_2_3.setText("  15:45 (Còn 0/50)");
            //layout 2
                labelTime2_1_1.setText("  00:45 (Còn 0/50)");
                labelTime2_1_3.setText("  01:00 (Còn 0/50)");
                labelTime2_1_2.setText("  12:15 (Còn 0/50)");
                labelTime2_2_1.setText("  13:15 (Còn 0/50)");
                labelTime2_2_2.setText("  16:15 (Còn 0/50)");
                labelTime2_2_3.setText("  18:15 (Còn 0/50)");
                //layout3
            labelTime3_1_1.setText("  11:00 (Còn 0/50)");
            labelTime3_1_2.setText("  12:30 (Còn 0/50)");
            labelTime3_1_3.setText("  13:30 (Còn 0/50)");
            labelTime3_2_1.setText("  14:15 (Còn 0/50)");
            labelTime3_2_2.setText("  15:15 (Còn 0/50)");
            labelTime3_2_3.setText("  16:15 (Còn 0/50)");
            
    }
    @FXML private void maiOn(MouseEvent enven){
        coMai=true;
       resetColorLabelNgay();
        tempLichSuPhim ="Phim: Mai";
        clickMovie();
        resetText();
        //nạp dữ liệu địa điểm và thời gian
            //ngay
            labelMuaDo2310.setText("  23/10");
            labelMuaDo2410.setText("  24/10");
            labelMuaDo2510.setText("  25/10");
            //địa điểm
                 //layout 1
                labelDiaDiem1_1.setText("Galaxy Kinh Dương Vương");
                labelDiaDiem1_2.setText("Galaxy Linh Trung");
                
                //layout 2
                labelDiaDiem2_1.setText("Galaxy Nguyễn Văn Quá");
                labelDiaDiem2_2.setText("Galaxy Trung Chánh");
                
                //layout 3
                labelDiaDiem3_1.setText("Galaxy Quang Trung");
                labelDiaDiem3_2.setText("Galaxy Nguyễn Du");
           //thoi gian
             //layout 1
            labelTime1_1_1.setText("  01:45 (Còn 0/50)");
            labelTime1_1_2.setText("  02:00 (Còn 0/50)");
            labelTime1_1_3.setText("  11:00 (Còn 0/50)");
            labelTime1_2_1.setText("  12:00 (Còn 0/50)");
            labelTime1_2_2.setText("  14:00 (Còn 0/50)");
            labelTime1_2_3.setText("  16:45 (Còn 0/50)");
            //layout 2
                labelTime2_1_1.setText("  00:30 (Còn 0/50)");
                labelTime2_1_3.setText("  04:00 (Còn 0/50)");
                labelTime2_1_2.setText("  02:30 (Còn 0/50)");
                labelTime2_2_1.setText("  09:15 (Còn 0/50)");
                labelTime2_2_2.setText("  10:15 (Còn 0/50)");
                labelTime2_2_3.setText("  11:15 (Còn 0/50)");
                //layout3
            labelTime3_1_1.setText("  12:00 (Còn 0/50)");
            labelTime3_1_2.setText("  13:30 (Còn 0/50)");
            labelTime3_1_3.setText("  14:30 (Còn 0/50)");
            labelTime3_2_1.setText("  15:15 (Còn 0/50)");
            labelTime3_2_2.setText("  16:15 (Còn 0/50)");
            labelTime3_2_3.setText("  17:15 (Còn 0/50)");
    }
    @FXML private void denAmHonOn(MouseEvent enven){
        coDenAmHon=true;
        resetColorLabelNgay();
        tempLichSuPhim ="Phim: Đèn Âm Hồn";
        clickMovie();
        resetText();
        //nạp dữ liệu địa điểm và thời gian
            //ngay
            labelMuaDo2310.setText("  23/10");
            labelMuaDo2410.setText("  24/10");
            labelMuaDo2510.setText("  25/10");
            //địa điểm
                 //layout 1
                labelDiaDiem1_1.setText("Galaxy Kinh Dương Vương");
                labelDiaDiem1_2.setText("Galaxy Huỳnh Tân Phát");
                
                //layout 2
                labelDiaDiem2_1.setText("Lotte Gò Vấp");
                labelDiaDiem2_2.setText("Galaxy Nguyễn Văn Quá");
                
                //layout 3
                labelDiaDiem3_1.setText("Lotte Gò Vấp");
                labelDiaDiem3_2.setText("Galaxy Sala");
           //thoi gian
                    //layout 1 — Suất chiếu buổi sáng đến đầu trưa
                    labelTime1_1_1.setText("  08:30 (Còn 0/50)");
                    labelTime1_1_2.setText("  09:45 (Còn 0/50)");
                    labelTime1_1_3.setText("  11:00 (Còn 0/50)");
                    labelTime1_2_1.setText("  12:15 (Còn 0/50)");
                    labelTime1_2_2.setText("  13:30 (Còn 0/50)");
                    labelTime1_2_3.setText("  14:45 (Còn 0/50)");

                    //layout 2 — Suất chiếu buổi chiều đến đầu tối
                    labelTime2_1_1.setText("  15:30 (Còn 0/50)");
                    labelTime2_1_2.setText("  16:45 (Còn 0/50)");
                    labelTime2_1_3.setText("  18:00 (Còn 0/50)");
                    labelTime2_2_1.setText("  19:15 (Còn 0/50)");
                    labelTime2_2_2.setText("  20:30 (Còn 0/50)");
                    labelTime2_2_3.setText("  21:45 (Còn 0/50)");

                    //layout 3 — Suất chiếu khuya
                    labelTime3_1_1.setText("  22:15 (Còn 0/50)");
                    labelTime3_1_2.setText("  23:00 (Còn 0/50)");
                    labelTime3_1_3.setText("  23:45 (Còn 0/50)");
                    labelTime3_2_1.setText("  00:30 (Còn 0/50)");
                    labelTime3_2_2.setText("  01:15 (Còn 0/50)");
                    labelTime3_2_3.setText("  02:00 (Còn 0/50)");
    }
    @FXML private void boGiaOn(MouseEvent enven){
        coBoGia=true;
        resetColorLabelNgay();
        tempLichSuPhim ="Phim: Bố Già";
        clickMovie();
        resetText();
        //nạp dữ liệu địa điểm và thời gian
            //ngay
            labelMuaDo2310.setText("  23/10");
            labelMuaDo2410.setText("  24/10");
            labelMuaDo2510.setText("  25/10");
            //địa điểm
                 //layout 1
                labelDiaDiem1_1.setText("Galaxy Kinh Dương Vương");
                labelDiaDiem1_2.setText("Galaxy Huỳnh Tân Phát");
                
                //layout 2
                labelDiaDiem2_1.setText("Lotte Gò Vấp");
                labelDiaDiem2_2.setText("Galaxy Nguyễn Văn Quá");
                
                //layout 3
                labelDiaDiem3_1.setText("Lotte Gò Vấp");
                labelDiaDiem3_2.setText("Galaxy Sala");
           //thoi gian
            //layout 1
                labelTime1_1_1.setText("  09:45 (Còn 0/50)");
                labelTime1_1_2.setText("  11:00 (Còn 0/50)");
                labelTime1_1_3.setText("  13:00 (Còn 0/50)");
                labelTime1_2_1.setText("  15:00 (Còn 0/50)");
                labelTime1_2_2.setText("  17:00 (Còn 0/50)");
                labelTime1_2_3.setText("  19:45 (Còn 0/50)");
            //layout 2
                labelTime2_1_1.setText("  09:45 (Còn 0/50)");
                labelTime2_1_3.setText("  14:00 (Còn 0/50)");
                labelTime2_1_2.setText("  13:15 (Còn 0/50)");
                labelTime2_2_1.setText("  14:15 (Còn 0/50)");
                labelTime2_2_2.setText("  16:15 (Còn 0/50)");
                labelTime2_2_3.setText("  18:15 (Còn 0/50)");
                //layout3
            labelTime3_1_1.setText("  19:00 (Còn 0/50)");
            labelTime3_1_2.setText("  20:30 (Còn 0/50)");
            labelTime3_1_3.setText("  21:30 (Còn 0/50)");
            labelTime3_2_1.setText("  14:15 (Còn 0/50)");
            labelTime3_2_2.setText("  15:15 (Còn 0/50)");
            labelTime3_2_3.setText("  16:15 (Còn 0/50)");
    }
    

  @FXML private void dangXuatOn(ActionEvent even)throws IOException{
      Stage currentStage = (Stage) ((Node) even.getSource()).getScene().getWindow();
      currentStage.close();

    // 🟩 2. Mở lại màn hình đăng nhập
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/login_phim/FXMLDocument.fxml"));
    Stage stage = new Stage();
    Scene scene = new Scene(loader.load());
    stage.setScene(scene);
    stage.setTitle("Đăng nhập - MIKEE Cinema");
    stage.show();
  }

    
    
    //xử lý chọn suất chiếu
    //label 23/10
    @FXML private void labelMuaDo2310MouseOn(MouseEvent event){
        tempLichSuNgayChieu="Ngày Chiếu: 23/10";
        
        
        paneMuaDo2310.setDisable(false);
        paneMuaDo2310.setOpacity(1);
        labelMuaDo2310.setStyle("");
        labelMuaDo2310.setStyle("-fx-background-color:#0878e8;-fx-background-radius:13;-fx-text-fill:#ffffff;");
    
        labelMuaDo2410.setStyle("");
        labelMuaDo2410.setStyle("-fx-background-color:#ffffff;-fx-background-radius:13;-fx-text-fill:#000000;");
        labelMuaDo2510.setStyle("");
        labelMuaDo2510.setStyle("-fx-background-color:#ffffff;-fx-background-radius:13;-fx-text-fill:#000000;");
    
        paneMuaDo2410.setDisable(true);
        paneMuaDo2410.setOpacity(0);
        paneMuaDo2510.setDisable(true);
        paneMuaDo2510.setOpacity(0);
        paneMuaDo2310.setDisable(false);
        paneMuaDo2410.setDisable(false);
        paneMuaDo2510.setDisable(false);
        
    }
    //label 24/10
    @FXML private void labelMuaDo2410MouseOn(MouseEvent event){
        tempLichSuNgayChieu="Ngày Chiếu: 24/10";
        
        paneMuaDo2410.setDisable(false);
        paneMuaDo2410.setOpacity(1);
        labelMuaDo2410.setStyle("");
        labelMuaDo2410.setStyle("-fx-background-color:#0878e8;-fx-background-radius:13;-fx-text-fill:#ffffff;");
  
        labelMuaDo2310.setStyle("");
        labelMuaDo2310.setStyle("-fx-background-color:#ffffff;-fx-background-radius:13;-fx-text-fill:#000000;");
        labelMuaDo2510.setStyle("");
        labelMuaDo2510.setStyle("-fx-background-color:#ffffff;-fx-background-radius:13;-fx-text-fill:#000000;");
    
        paneMuaDo2310.setDisable(true);
        paneMuaDo2310.setOpacity(0); 
        paneMuaDo2510.setDisable(true);
        paneMuaDo2510.setOpacity(0);
        paneMuaDo2310.setDisable(false);
        paneMuaDo2410.setDisable(false);
        paneMuaDo2510.setDisable(false);
    }
    //label 25/10
    @FXML private void labelMuaDo2510MouseOn(MouseEvent event){
        tempLichSuNgayChieu="Ngày Chiếu: 25/10";
        
        paneMuaDo2510.setDisable(false);
        paneMuaDo2510.setOpacity(1);
    
        labelMuaDo2510.setStyle("");
        labelMuaDo2510.setStyle("-fx-background-color:#0878e8;-fx-background-radius:13;-fx-text-fill:#ffffff;");
        labelMuaDo2310.setStyle("");
        labelMuaDo2310.setStyle("-fx-background-color:#ffffff;-fx-background-radius:13;-fx-text-fill:#000000;");
        labelMuaDo2410.setStyle("");    
        labelMuaDo2410.setStyle("-fx-background-color:#ffffff;-fx-background-radius:13;-fx-text-fill:#000000;");
    
        paneMuaDo2410.setDisable(true);
        paneMuaDo2410.setOpacity(0);
        paneMuaDo2310.setDisable(true);
        paneMuaDo2310.setOpacity(0);
        paneMuaDo2310.setDisable(false);
        paneMuaDo2410.setDisable(false);
        paneMuaDo2510.setDisable(false);
    }
    // them vé vào lich su
    private static void addLichSuVe(String addUsername,
                                    String addTempPhim,
                                    String addTempNgayChieu,
                                    String addTempDiaDiem,
                                    String addTempGioChieu,
                                    String addTempSoGhe) throws IOException {

        File file = new File("accout/lichSuVe.csv");
        // Ghi nối tiếp vào cuối file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {

            // Ghi 1 dòng dữ liệu (thêm username ở đầu)
            bw.write(addUsername + "," +
                     addTempPhim + "," +
                     addTempNgayChieu + "," +
                     addTempDiaDiem + "," +
                     addTempGioChieu + "," +
                     addTempSoGhe);

            bw.newLine(); // xuống dòng

            System.out.println("Đã thêm lịch sử vé cho tài khoản: " + addUsername);
        }
    }
    @FXML private ListView<String> listLichSu;

    // Khi bấm nút "Lịch sử"
    @FXML
    private void lichSuOn(ActionEvent event) {
        paneManHinhChinh.setDisable(true);
        paneManHinhChinh.setOpacity(0.1);
        dangXuat.setDisable(true);
        dangXuat.setOpacity(0.1);
        lichSu.setDisable(true);
        lichSu.setOpacity(0.1);
        paneLichSu.setOpacity(1);
        paneLichSu.setDisable(false);
        try {
            listLichSu.getItems().clear(); // Xóa danh sách cũ
            loadLichSuForUser(usernameLogin);   
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Hàm đọc file và lọc lịch sử đúng user
    private void loadLichSuForUser(String username) throws IOException {
        File file = new File("accout/lichSuVe.csv");

        if (!file.exists()) {
            System.out.println("️ Không tìm thấy file lịch sử!");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 6 && values[0].trim().equals("Name: "+username)) {
                    // Tạo chuỗi hiển thị trong ListView
                    String item = values[1] + " | " + values[2] + " |  " + values[3]
                                  + " |  " + values[4] + " |  " + values[5];
                    listLichSu.getItems().add(item);
                }
            }
        }
    }

    private void chayChuongTrinh(){
        if (coMuaDo){
            if(coLabelTime1_1_1) {tempLichSuGioChieu="Giờ Chiếu: 08:45";tempLichSuDiaDiem="CGV Aeon Bình Tân";}
            if(coLabelTime1_1_2) {tempLichSuGioChieu="Giờ Chiếu: 10:00";tempLichSuDiaDiem="CGV Aeon Bình Tân";}
            if(coLabelTime1_1_3) {tempLichSuGioChieu="Giờ Chiếu: 11:00";tempLichSuDiaDiem="CGV Aeon Bình Tân";}
            if(coLabelTime1_2_1) {tempLichSuGioChieu="Giờ Chiếu: 12:00";tempLichSuDiaDiem="CGV Tân Phú";}
            if(coLabelTime1_2_2) {tempLichSuGioChieu="Giờ Chiếu: 14:00";tempLichSuDiaDiem="CGV Tân Phú";}
            if(coLabelTime1_2_3) {tempLichSuGioChieu="Giờ Chiếu: 15:45";tempLichSuDiaDiem="CGV Tân Phú";}
            
            if(coLabelTime2_1_1) {tempLichSuGioChieu="Giờ Chiếu: 00:45";tempLichSuDiaDiem="CGV Hoàng Văn Thụ";}
            if(coLabelTime2_1_2) {tempLichSuGioChieu="Giờ Chiếu: 12:15";tempLichSuDiaDiem="CGV Hoàng Văn Thụ";}
            if(coLabelTime2_1_3) {tempLichSuGioChieu="Giờ Chiếu: 01:00";tempLichSuDiaDiem="CGV Hoàng Văn Thụ";}
            if(coLabelTime2_2_1) {tempLichSuGioChieu="Giờ Chiếu: 13:15";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_2_2) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_2_3) {tempLichSuGioChieu="Giờ Chiếu: 18:15";tempLichSuDiaDiem="Lotte Gò Vấp";}
            
            if(coLabelTime3_1_1) {tempLichSuGioChieu="Giờ Chiếu: 11:00";tempLichSuDiaDiem="Lotte Nam Sài Gòn";}
            if(coLabelTime3_1_2) {tempLichSuGioChieu="Giờ Chiếu: 12:30";tempLichSuDiaDiem="Lotte Nam Sài Gòn";}
            if(coLabelTime3_1_3) {tempLichSuGioChieu="Giờ Chiếu: 13:30";tempLichSuDiaDiem="Lotte Nam Sài Gòn";}
            if(coLabelTime3_2_1) {tempLichSuGioChieu="Giờ Chiếu: 14:15";tempLichSuDiaDiem="Lotte Phú Thọ";}
            if(coLabelTime3_2_2) {tempLichSuGioChieu="Giờ Chiếu: 15:15";tempLichSuDiaDiem="Lotte Phú Thọ";}
            if(coLabelTime3_2_3) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Lotte Phú Thọ";}
            
        }
        if (coLatMat7){
            if(coLabelTime1_1_1) {tempLichSuGioChieu="Giờ Chiếu: 09:45";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime1_1_2) {tempLichSuGioChieu="Giờ Chiếu: 11:00";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime1_1_3) {tempLichSuGioChieu="Giờ Chiếu: 13:00";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime1_2_1) {tempLichSuGioChieu="Giờ Chiếu: 15:00";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime1_2_2) {tempLichSuGioChieu="Giờ Chiếu: 17:00";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime1_2_3) {tempLichSuGioChieu="Giờ Chiếu: 19:45";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            
            if(coLabelTime2_1_1) {tempLichSuGioChieu="Giờ Chiếu: 09:45";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime2_1_2) {tempLichSuGioChieu="Giờ Chiếu: 14:00";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime2_1_3) {tempLichSuGioChieu="Giờ Chiếu: 13:15";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime2_2_1) {tempLichSuGioChieu="Giờ Chiếu: 14:15";tempLichSuDiaDiem="Galaxy Tân Bình";}
            if(coLabelTime2_2_2) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Galaxy Tân Bình";}
            if(coLabelTime2_2_3) {tempLichSuGioChieu="Giờ Chiếu: 18:15";tempLichSuDiaDiem="Galaxy Tân Bình";}
            
            if(coLabelTime3_1_1) {tempLichSuGioChieu="Giờ Chiếu: 19:00";tempLichSuDiaDiem="Galaxy Quang Trung";}
            if(coLabelTime3_1_2) {tempLichSuGioChieu="Giờ Chiếu: 20:30";tempLichSuDiaDiem="Galaxy Quang Trung";}
            if(coLabelTime3_1_3) {tempLichSuGioChieu="Giờ Chiếu: 21:30";tempLichSuDiaDiem="Galaxy Quang Trung";}
            if(coLabelTime3_2_1) {tempLichSuGioChieu="Giờ Chiếu: 14:15";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime3_2_2) {tempLichSuGioChieu="Giờ Chiếu: 15:15";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime3_2_3) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Galaxy Sala";}
            
        }
        if (coMai){
            if(coLabelTime1_1_1) {tempLichSuGioChieu="Giờ Chiếu: 01:45";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_1_2) {tempLichSuGioChieu="Giờ Chiếu: 02:00";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_1_3) {tempLichSuGioChieu="Giờ Chiếu: 11:00";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_2_1) {tempLichSuGioChieu="Giờ Chiếu: 12:00";tempLichSuDiaDiem="Galaxy Linh Trung";}
            if(coLabelTime1_2_2) {tempLichSuGioChieu="Giờ Chiếu: 14:00";tempLichSuDiaDiem="Galaxy Linh Trung";}
            if(coLabelTime1_2_3) {tempLichSuGioChieu="Giờ Chiếu: 16:45";tempLichSuDiaDiem="Galaxy Linh Trung";}
            
            if(coLabelTime2_1_1) {tempLichSuGioChieu="Giờ Chiếu: 00:30";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_1_2) {tempLichSuGioChieu="Giờ Chiếu: 02:30";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_1_3) {tempLichSuGioChieu="Giờ Chiếu: 04:00";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_2_1) {tempLichSuGioChieu="Giờ Chiếu: 09:15";tempLichSuDiaDiem="Galaxy Trung Chánh";}
            if(coLabelTime2_2_2) {tempLichSuGioChieu="Giờ Chiếu: 10:15";tempLichSuDiaDiem="Galaxy Trung Chánh";}
            if(coLabelTime2_2_3) {tempLichSuGioChieu="Giờ Chiếu: 11:15";tempLichSuDiaDiem="Galaxy Trung Chánh";}
            
            if(coLabelTime3_1_1) {tempLichSuGioChieu="Giờ Chiếu: 12:00";tempLichSuDiaDiem="Galaxy Quang Trung";}
            if(coLabelTime3_1_2) {tempLichSuGioChieu="Giờ Chiếu: 13:30";tempLichSuDiaDiem="Galaxy Quang Trung";}
            if(coLabelTime3_1_3) {tempLichSuGioChieu="Giờ Chiếu: 14:30";tempLichSuDiaDiem="Galaxy Quang Trung";}
            if(coLabelTime3_2_1) {tempLichSuGioChieu="Giờ Chiếu: 15:15";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime3_2_2) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            if(coLabelTime3_2_3) {tempLichSuGioChieu="Giờ Chiếu: 17:15";tempLichSuDiaDiem="Galaxy Nguyễn Du";}
            
        }
        if (coDenAmHon){
            if(coLabelTime1_1_1) {tempLichSuGioChieu="Giờ Chiếu: 08:30";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_1_2) {tempLichSuGioChieu="Giờ Chiếu: 09:46";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_1_3) {tempLichSuGioChieu="Giờ Chiếu: 11:00";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_2_1) {tempLichSuGioChieu="Giờ Chiếu: 12:15";tempLichSuDiaDiem="Galaxy Huỳnh Tấn Phát";}
            if(coLabelTime1_2_2) {tempLichSuGioChieu="Giờ Chiếu: 13:30";tempLichSuDiaDiem="Galaxy Huỳnh Tấn Phát";}
            if(coLabelTime1_2_3) {tempLichSuGioChieu="Giờ Chiếu: 14:45";tempLichSuDiaDiem="Galaxy Huỳnh Tấn Phát";}
            
            if(coLabelTime2_1_1) {tempLichSuGioChieu="Giờ Chiếu: 15:30";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_1_2) {tempLichSuGioChieu="Giờ Chiếu: 16:45";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_1_3) {tempLichSuGioChieu="Giờ Chiếu: 18:00";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_2_1) {tempLichSuGioChieu="Giờ Chiếu: 19:15";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_2_2) {tempLichSuGioChieu="Giờ Chiếu: 20:30";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_2_3) {tempLichSuGioChieu="Giờ Chiếu: 21:45";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            
            if(coLabelTime3_1_1) {tempLichSuGioChieu="Giờ Chiếu: 22:15";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime3_1_2) {tempLichSuGioChieu="Giờ Chiếu: 23:00";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime3_1_3) {tempLichSuGioChieu="Giờ Chiếu: 23:45";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime3_2_1) {tempLichSuGioChieu="Giờ Chiếu: 00:30";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime3_2_2) {tempLichSuGioChieu="Giờ Chiếu: 01:15";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime3_2_3) {tempLichSuGioChieu="Giờ Chiếu: 02:00";tempLichSuDiaDiem="Galaxy Sala";}
            
        }
        if (coBoGia){
            if(coLabelTime1_1_1) {tempLichSuGioChieu="Giờ Chiếu: 09:45";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_1_2) {tempLichSuGioChieu="Giờ Chiếu: 11:00";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_1_3) {tempLichSuGioChieu="Giờ Chiếu: 13:00";tempLichSuDiaDiem="Galaxy Kinh Dương Vương";}
            if(coLabelTime1_2_1) {tempLichSuGioChieu="Giờ Chiếu: 15:00";tempLichSuDiaDiem="Galaxy Huỳnh Tấn Phát";}
            if(coLabelTime1_2_2) {tempLichSuGioChieu="Giờ Chiếu: 17:00";tempLichSuDiaDiem="Galaxy Huỳnh Tấn Phát";}
            if(coLabelTime1_2_3) {tempLichSuGioChieu="Giờ Chiếu: 19:45";tempLichSuDiaDiem="Galaxy Huỳnh Tấn Phát";}
            
            if(coLabelTime2_1_1) {tempLichSuGioChieu="Giờ Chiếu: 09:45";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_1_2) {tempLichSuGioChieu="Giờ Chiếu: 13:15";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_1_3) {tempLichSuGioChieu="Giờ Chiếu: 14:00";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime2_2_1) {tempLichSuGioChieu="Giờ Chiếu: 14:15";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_2_2) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            if(coLabelTime2_2_3) {tempLichSuGioChieu="Giờ Chiếu: 18:15";tempLichSuDiaDiem="Galaxy Nguyễn Văn Quá";}
            
            if(coLabelTime3_1_1) {tempLichSuGioChieu="Giờ Chiếu: 19:00";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime3_1_2) {tempLichSuGioChieu="Giờ Chiếu: 20:30";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime3_1_3) {tempLichSuGioChieu="Giờ Chiếu: 21:30";tempLichSuDiaDiem="Lotte Gò Vấp";}
            if(coLabelTime3_2_1) {tempLichSuGioChieu="Giờ Chiếu: 14:15";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime3_2_2) {tempLichSuGioChieu="Giờ Chiếu: 15:15";tempLichSuDiaDiem="Galaxy Sala";}
            if(coLabelTime3_2_3) {tempLichSuGioChieu="Giờ Chiếu: 16:15";tempLichSuDiaDiem="Galaxy Sala";}
            
        }
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        paneManHinhChinh.setDisable(false);
        paneManHinhChinh.setOpacity(1);
        paneChonSuat.setDisable(true);
        paneChonSuat.setOpacity(0);
        images_nen.setOpacity(1);
        dangXuat.setDisable(false);
        dangXuat.setOpacity(1);
        lichSu.setDisable(false);
        lichSu.setOpacity(1);
        paneGhe.setDisable(true);
        paneGhe.setOpacity(0);
       if (usernameLogin != null && xinChao != null) {
        xinChao.setText("Xin Chào: " + usernameLogin);
    }
        
    }    
    
}
